let boxes = document.querySelectorAll(".box")
let reset = document.querySelector(".Reset")
let newgame =  document.querySelector(".newgame")
let msgconten = document.querySelector(".msg-conten")
let msg = document.querySelector("#msg")

let turnO = true;

const winpeturns = [
  [0, 1, 2],
  [0, 3, 6],
  [0, 4, 8],
  [1, 4, 7],
  [2, 5, 8],
  [2, 4, 6],
  [3, 4, 5],
  [6, 7, 8],
];

const resategame = () =>{
turnO = true;
enableboxes();
msgconten.classList.add("hide")
}

boxes.forEach((box) => {
  box.addEventListener("click", () => {
    if (turnO) { //player O
      box.innerText = "O";
      turnO = false;
    } else { //player X
      box.innerText = "X";
      turnO = true;
    }
    box.disabled = true;

    checkwinner();
  });
});



const disabledbox =() =>{
  for(let box of boxes){
    box.disabled = true;
  }
} 

const enableboxes = () =>{
  for(let box of boxes){
    box.disabled = false;
    box.innerText = "";
  }
} 



const showwinner = (winner)=>{
  msg.innerText = `congratulations winner is ${winner}`;
  msgconten.classList.remove("hide");
disabledbox();

}


const checkwinner = () => {
  for (let peturn of winpeturns) {
  let pos1 = boxes[peturn[0]].innerText;
  let pos2 = boxes[peturn[1]].innerText;
  let pos3 = boxes[peturn[2]].innerText;

if(pos1 != "" && pos2 != "" && pos3 != "")
   if(pos1 === pos2 && pos2 === pos3){
    console.log("winner", pos1);
showwinner(pos1);

   }
  };


};
newgame.addEventListener("click", resategame);
reset.addEventListener("click", resategame)