const express = require("express");
const path = require("path");
const app = express();
const hbs = require("hbs");

const Register = require("./models/ragisters"); // Ensure this path and filename are correct

require("./db/conn"); // Ensure this path is correct
const port = process.env.PORT || 3000;

// Paths for static files and views
const static_path = path.join(__dirname, "../public");
const template_path = path.join(__dirname, "../template/views");
const partials_path = path.join(__dirname, "../template/partials");

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Middleware
app.use(express.static(static_path));

// Set views directory and view engine
app.set('views', template_path);
app.set("view engine", "hbs");
hbs.registerPartials(partials_path);

// Define routes
app.get("/", (req, res) => {
  res.render("index");  // Renders views/index.hbs
});

app.get("/program", (req, res) => {
  res.render("program");
});

app.get("/About", (req, res) => {
  res.render("About");
});

app.get("/register", (req, res) => { // Updated path for consistency
  res.render("register");
});

app.get("/login", (req, res) => {
  res.render("login");
});

// Create a new user in our database
app.post("/register", async (req, res) => { // Updated path for consistency
  try {
    const password = req.body.password;
    const cpassword = req.body.confirmpassword;

    if (password === cpassword) {
      // Hash the password before saving
      const hashedPassword = await bcrypt.hash(password, 10);
      
      const registerStudent = new Register({
        username: req.body.username,
        emailid: req.body.emailid,
        mobile: req.body.mobile,
        gender: req.body.gender,
        password: hashedPassword,
        confirmpassword: hashedPassword
      });

      const registered = await registerStudent.save();
      res.status(201).render("index");
    } else {
      res.send("Passwords are not matching");
    }
  } catch (error) {
    res.status(400).send(error);
  }
});

// Login check
app.post("/login", async (req, res) => {
  try {
    const emailid = req.body.emailid;
    const password = req.body.password;

    const useremail = await Register.findOne({ emailid: emailid });
    if (useremail) {
      const isMatch = await bcrypt.compare(password, useremail.password);
      if (isMatch) {
        res.status(201).render("index");
      } else {
        res.send("Invalid login credentials");
      }
    } else {
      res.send("Invalid login credentials");
    }
  } catch (error) {
    res.status(400).send("Invalid Email");
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
